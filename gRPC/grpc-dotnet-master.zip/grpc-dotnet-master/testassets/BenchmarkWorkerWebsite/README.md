Implementation of benchmark worker that is compatible with the gRPC benchmarking stack:
https://grpc.io/docs/guides/benchmarking.html


