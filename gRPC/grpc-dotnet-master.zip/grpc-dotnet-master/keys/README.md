Contents
--------

- Grpc.public.snk:
  Public key to verify strong name of gRPC assemblies.
- Grpc.snk:
  Signing key to provide strong name of gRPC assemblies.
  As per https://msdn.microsoft.com/en-us/library/wd40t7ad(v=vs.110).aspx
  signing key should be checked into the repository.

These keys originated from https://github.com/grpc/grpc/tree/master/src/csharp/keys.
